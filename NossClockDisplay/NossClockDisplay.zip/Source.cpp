/* Name: Jacob Sullivan
   Date: 5/19/2021
   This program will properly display two clocks, one in 12-hour
   format and one in 24-hour format. It will allow a user to add
   an hour, a minute, or a second to the clock, while maintaining values
   that are valid for a clock (no second past 59 seconds for example).
   */

#include <iostream>
#include <string>
#include "12Hour.h"
#include "24Hour.h"
#include <iomanip>
using namespace std;

/* The following block handles the output of our clock display to the screen,
   properly formatting the display to Chada Tech's specifications. Here, I use "getters" to input data
   from my functions directly into my clock format. This allows me to update the time in the clock via functions 
   and user input. The setfill() and setw() calls below I learned about from the tutoring service. These handle
   format so when any of our variable is a single digit, width is set to 2 and a 0 is used to fill the space before
   the digit, maintaining our desired format. */

void displayClock(_12HourClock clock12, _24HourClock clock24) {
	cout << "************************** **************************" << endl;
	cout << "*      12-Hour Clock     * *      24-Hour Clock     *" << endl;
    cout << "*      " << setfill('0') << setw(2) << clock12.getHours() << ":" << setfill('0') << setw(2) << clock12.getMinutes();
    cout << ":" << setfill('0') << setw(2) << clock12.getSeconds() << " " << clock12.getAMPM();
    cout << "     * *        " << setfill('0') << setw(2) << clock24.getHours() << ":" << setfill('0') << setw(2) << clock24.getMinutes();
    cout << ":" << setfill('0') << setw(2) << clock24.getSeconds() << "        *" << endl;
	cout << "************************** **************************" << endl;
};

/* This block simply outputs the menu of possible choices for our user to assist in ease of use for our program. */
void displayMenu() {
	cout << "**************************" << endl;
	cout << "* 1 - Add One Hour       *" << endl;
	cout << "* 2 - Add One Minute     *" << endl;
	cout << "* 3 - Add One Second     *" << endl;
	cout << "* 4 - Exit Program       *" << endl;
	cout << "**************************" << endl;
};

/* The following block is our Main method, which will simply take care of execution
   of our program by using method calls in the proper order.*/

int main() {
    int userInput = 0; //initializes user input so our while loop later is entered
    /*These next two lines define objects of our two clock classes for use in main.
      We use them to initalize our hours, minutes, and seconds, and use them as parameters
      for our "displayClock" function. */

    _12HourClock clock12(11, 57, 36);
    _24HourClock clock24(11, 57, 36);

    while (userInput != 4) { //sets condition that while userInput is not "exit" the program will continue to run
        displayClock(clock12, clock24);
        displayMenu();


        cin >> userInput;

        /* The following swtich statement block handles each case for possible user input. If user input is 1,
           our addHour function is called. 2 addMinute is called. 3 addSecond is called. And 4 the program is
           exited. After 1, 2, or 3, the clock is displayed again, updated, and the program waits for another input.
           Our default case simply prints "invalid input", as any other input other than the menu options
           do not interact with the program.*/
        switch (userInput) {
        case 1:
            clock12.addHour();
            clock24.addHour();
            displayClock(clock12, clock24);
            break;
        case 2:
            clock12.addMinute();
            clock24.addMinute();
            displayClock(clock12, clock24);
            break;
        case 3:
            clock12.addSecond();
            clock24.addSecond();
            displayClock(clock12, clock24);
            break;
        case 4:
            cout << "Thank you! Goodbye!";
            break;
        default:
            cout << "Invalid input!" << endl;
            break;

        }
    }
}